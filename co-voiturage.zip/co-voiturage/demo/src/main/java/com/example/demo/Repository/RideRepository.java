package com.example.demo.Repository;

import com.example.demo.models.Ride;
import com.example.demo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Driver;
import java.time.LocalDateTime;
import java.util.List;

public interface RideRepository extends JpaRepository<Ride, Integer> {
    List<Ride> findByStartAndDestinationAndPriceLessThanEqualAndStart_dateAfterAndDriver(String start, String destination, Double maxPrice, LocalDateTime startDate, User driver);
    List<Ride> findByStartAndDestinationAndPriceLessThanEqualAndStart_dateAfter(String start, String destination, Double maxPrice, LocalDateTime startDate);

}
