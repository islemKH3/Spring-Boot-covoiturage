package com.example.demo.Service;

import com.example.demo.Repository.HistoryRepository;
import com.example.demo.models.History;
import com.example.demo.models.Reservation;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistoryService {

    @Autowired
    HistoryRepository historyRepository;

    public List<Reservation> getPastReservationsByUser(User user) {
        History history = historyRepository.findByUser(user);
        if (history == null) {
            throw new IllegalArgumentException("No history found for user with ID: " + user);
        }
        return history.getPastReservations();
    }

    public List<Reservation> getUpcomingReservationsByUser(User user) {
        History history = historyRepository.findByUser(user);
        if (history == null) {
            throw new IllegalArgumentException("No history found for user: " + user.getName() + user.getLastname());
        }
        return history.getUpcomingReservations();
    }



}
