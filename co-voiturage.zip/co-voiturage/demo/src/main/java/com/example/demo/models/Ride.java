package com.example.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table (name="ride")
public class Ride {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_route;
    private String start;
    private String destination;
    @Setter
    @Getter
    private LocalDateTime start_date;
    @Setter
    @Getter
    private int nbr_places;
    private double price;

    @Column (nullable=true)
    private String note;

    @ManyToOne
    private User Driver;

    public void decreaseAvailableSeats(int seats) {
        if (nbr_places >= seats) {
            nbr_places -= seats;
        } else {
            throw new IllegalArgumentException("Not enough seats available.");
        }
    }

    public void increaseAvailableSeats(int seats) {
        nbr_places += seats;
    }

}
