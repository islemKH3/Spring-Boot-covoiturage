package com.example.demo.Repository;

import com.example.demo.models.Reservation;
import com.example.demo.models.Ride;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Integer> {
    Reservation findByRide(Ride ride);
    List<Reservation> findByRateIsNotNull();
    List<Reservation> findByRateIsNull();
}
