package com.example.demo.models;

import jakarta.persistence.*;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="user")

public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_user;
    @Getter
    @Setter
    private String role;
    @Getter
    @Setter
    @Column(unique = true, nullable = false)
    private String username;
    @Getter
    @Setter
    private String password;
    @Getter
    @Setter
    private String name;
    @Getter
    @Setter
    private String lastname;
    @Getter
    @Setter
    private int rate;
    @Getter
    @Setter
    private Long nbr_rates;

    @Getter
    @Setter
    @OneToMany
    private List<Comment> comments;

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public double getAverageRate() {
        return nbr_rates > 0 ? (double) rate / nbr_rates : 0.0;
    }

    public void addRate(int newRate) {
        if (newRate < 0 || newRate > 5) {
            throw new IllegalArgumentException("The rate must be in between 0 and 5");
        }
        rate += newRate;
        nbr_rates++;
    }
}
