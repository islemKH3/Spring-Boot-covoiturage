package com.example.demo.Service;

import com.example.demo.models.Ride;
import com.example.demo.Repository.RideRepository;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class RideService {
    @Autowired
    private RideRepository rideRepository;

    public Ride createRide(Ride ride) {
        return rideRepository.save(ride);
    }

    public List<Ride> searchRides(String start, String destination, Double maxPrice, User driver, LocalDateTime afterDate) {

        if (maxPrice==null || afterDate==null || start==null || destination==null) {
            throw new IllegalArgumentException("Fill in all the required parameters");
        } else if (driver == null) {
            return rideRepository.findByStartAndDestinationAndPriceLessThanEqualAndStart_dateAfter(start, destination, maxPrice, afterDate);
        } else {
            return rideRepository.findByStartAndDestinationAndPriceLessThanEqualAndStart_dateAfterAndDriver(start, destination, maxPrice, afterDate, driver);
        }
    }
}
