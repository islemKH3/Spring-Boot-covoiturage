package com.example.demo.Controller;

import com.example.demo.models.Ride;
import com.example.demo.Service.RideService;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/rides")
public class RideController {
    @Autowired
    private RideService rideService;

    @PostMapping
    public Ride createRide(@RequestBody Ride ride) {
        return rideService.createRide(ride);
    }

    @GetMapping
    public List<Ride> searchRides(@RequestParam(required = true) String start,
                                  @RequestParam(required = true) String destination,
                                  @RequestParam(required = true) Double maxPrice,
                                  @RequestParam(required = false) User driver,
                                  @RequestParam(required = true) LocalDateTime afterDate) {
        return rideService.searchRides(start, destination, maxPrice, driver, afterDate);
    }
}
