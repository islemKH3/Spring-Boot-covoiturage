package com.example.demo.Controller;

import com.example.demo.Service.UserService;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.registerUser(user);
    }

    @PostMapping("/login")
    public User login(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");
        return userService.authenticate(username, password);
    }

    @GetMapping("{username}")
    public User getUserByUsername(@PathVariable String username) {
        return userService.findUserByUsername(username);
    }

    @PutMapping("/{username}/rate")
    public ResponseEntity<User> addRate(
            @PathVariable String username,
            @RequestParam int rate) {
        return ResponseEntity.ok(userService.addRateToUser(username, rate));
    }

    @GetMapping("/{username}/averageRate")
    public ResponseEntity<Double> getAverageRate(@PathVariable String username) {
        return ResponseEntity.ok(userService.getAverageRate(username));
    }
}
