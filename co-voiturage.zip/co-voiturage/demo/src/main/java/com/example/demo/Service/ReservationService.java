package com.example.demo.Service;

import com.example.demo.Repository.ReservationRepository;
import com.example.demo.Repository.RideRepository;
import com.example.demo.models.Reservation;
import com.example.demo.models.Ride;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReservationService {
    @Autowired
    private ReservationRepository reservationRepository;
    @Autowired
    private RideRepository rideRepository;

    public Reservation addRate(Ride ride, Integer rate) {
        Reservation reservation = reservationRepository.findByRide(ride);
        if (reservation==null)
        {
            throw new IllegalArgumentException("Reservation not found");
        }
        if (rate < 0 || rate > 5) {
            throw new IllegalArgumentException("Rate must be between 0 and 5");
        }
        reservation.setRate(rate);
        return reservationRepository.save(reservation);
    }

    public Reservation createReservation(Reservation reservation) {

        Ride ride = reservation.getRide();
        if (ride == null) {
            throw new IllegalArgumentException("Ride does not exist.");
        }

        if (ride.getNbr_places() < reservation.getNbr_places()) {
            throw new IllegalArgumentException("Not enough seats available for this ride.");
        }

        ride.decreaseAvailableSeats(reservation.getNbr_places());
        rideRepository.save(ride);

        return reservationRepository.save(reservation);
    }

    public void cancelReservation(Ride ride) {

        Reservation reservation = reservationRepository.findByRide(ride);

        ride.increaseAvailableSeats(reservation.getNbr_places());
        rideRepository.save(ride);

        reservationRepository.delete(reservation);
    }
}
