package com.example.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="reservation")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_res;
    @Setter
    @Getter
    private int nbr_places;
    @Setter
    @Getter

    private Integer rate; //null if the ride is not done yet

    @Setter
    @Getter
    @ManyToOne
    private Ride ride;

    @OneToOne
    private User passager;

}
