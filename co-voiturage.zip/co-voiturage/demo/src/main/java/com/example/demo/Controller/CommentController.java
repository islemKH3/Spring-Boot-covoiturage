package com.example.demo.Controller;

import com.example.demo.Service.CommentService;
import com.example.demo.models.Comment;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
public class CommentController {
    @Autowired
    private CommentService commentService;

    @PostMapping
    public Comment addComment(@RequestBody Comment comment) {
        return commentService.addComment(comment);
    }

    @GetMapping("/receiver/{receiver}")
    public List<Comment> getCommentsByReceiver(@PathVariable User receiver) {
        return commentService.getCommentsByReceiver(receiver);
    }

    @GetMapping("/author/{author}")
    public List<Comment> getCommentsByAuthor(@PathVariable User author) {
        return commentService.getCommentsByAuthor(author);
    }
}
