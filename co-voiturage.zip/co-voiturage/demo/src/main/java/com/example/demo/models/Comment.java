package com.example.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="comment")
public class Comment {
    @Setter
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_com;
    private String content;

    @ManyToOne
    private User author;

    @ManyToOne
    private User receiver;

}
