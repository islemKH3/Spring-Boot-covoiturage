package com.example.demo.Repository;

import com.example.demo.models.Comment;
import com.example.demo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    List<Comment> findByReceiver(User receiver);

    List<Comment> findByAuthor(User author);
}
