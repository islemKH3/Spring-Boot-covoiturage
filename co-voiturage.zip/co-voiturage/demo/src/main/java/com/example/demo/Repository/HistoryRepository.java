package com.example.demo.Repository;

import com.example.demo.models.History;
import com.example.demo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistoryRepository extends JpaRepository <History, Integer> {
    History findByUser(User user);
}
