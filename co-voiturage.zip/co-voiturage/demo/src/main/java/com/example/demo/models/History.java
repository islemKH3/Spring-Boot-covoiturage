package com.example.demo.models;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table (name="history")
public class History {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id_history;

    @OneToOne
    private User user;

    @OneToMany
    private List<Reservation> reservations;

    public List<Reservation> getPastReservations() {
        return reservations.stream()
                .filter(reservation -> reservation.getRide().getStart_date().isBefore(LocalDateTime.now()))
                .toList();
    }

    public List<Reservation> getUpcomingReservations() {
        return reservations.stream()
                .filter(reservation -> reservation.getRide().getStart_date().isAfter(LocalDateTime.now()))
                .toList();
    }
}
