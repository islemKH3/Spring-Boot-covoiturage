package com.example.demo.Service;

import com.example.demo.Repository.CommentRepository;
import com.example.demo.models.Comment;
import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentService {
    @Autowired
    private CommentRepository commentRepository;

    public Comment addComment(Comment comment) {
        return commentRepository.save(comment);
    }

    public List<Comment> getCommentsByReceiver(User receiver) {
        return commentRepository.findByReceiver(receiver);
    }

    public List<Comment> getCommentsByAuthor(User author) {
        return commentRepository.findByAuthor(author);
    }
}