package com.example.demo.Controller;

import com.example.demo.Service.ReservationService;
import com.example.demo.models.Reservation;
import com.example.demo.models.Ride;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/reservations")
public class ReservationController {
    @Autowired
    private ReservationService reservationService;

    @PostMapping
    public Reservation createReservation(@RequestBody Reservation reservation) {
        return reservationService.createReservation(reservation);
    }

    @DeleteMapping("/{ride}")
    public void cancelReservation(@PathVariable Ride ride) {
        reservationService.cancelReservation(ride);
    }
}
